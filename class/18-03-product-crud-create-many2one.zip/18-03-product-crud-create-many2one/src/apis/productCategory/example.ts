class Aaa {
  private apple;

  ggg() {
    console.log('안녕하세요');
  }
}

const aa = new Aaa();
// aa.apple = 5;
